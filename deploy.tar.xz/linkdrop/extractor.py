"""Video discovery: yt-dlp, real HTML media references, optional browser observation."""
from __future__ import annotations

import asyncio
from dataclasses import dataclass, field
from html import unescape
import json
import re
from urllib.parse import urljoin, urlsplit

from bs4 import BeautifulSoup
import httpx

from .security import LinkError, ensure_public_url, safe_request

MAX_HTML = 2 * 1024 * 1024
MAX_MEDIA_CANDIDATES = 18
VIDEO_SUFFIX = re.compile(r"\.(?:mp4|m4v|mov|webm|m3u8)(?:$|[?#])", re.I)
MEDIA_LINKS = re.compile(r"https?:\\?/\\?/[^\s<>\"']+?\.(?:mp4|m4v|mov|webm|m3u8)(?:\?[^\s<>\"']{0,200})?", re.I)
DIRECT_VIDEO = re.compile(r"\.(?:mp4|m4v|mov|webm)(?:$|[?#])", re.I)
HLS_VIDEO = re.compile(r"\.m3u8(?:$|[?#])", re.I)


@dataclass
class Choice:
    id: str
    label: str
    source: str  # yt-dlp / direct / hls
    url: str
    ext: str = "mp4"
    size: int | None = None
    height: int | None = None
    headers: dict[str, str] = field(default_factory=dict)
    ytdlp_id: str = ""

    def public_dict(self) -> dict:
        return {"id": self.id, "label": self.label, "ext": self.ext, "bytes": self.size, "height": self.height}


@dataclass
class Result:
    url: str
    title: str
    platform: str
    choices: list[Choice]
    thumbnail: str = ""
    duration: float | None = None
    method: str = ""
    notes: str = ""

    def public_dict(self) -> dict:
        return {
            "url": self.url, "title": self.title, "platform": self.platform,
            "qualities": [x.public_dict() for x in self.choices],
            "thumbnail": self.thumbnail, "duration": self.duration,
            "method": self.method, "notes": self.notes,
        }


def platform_name(url: str) -> str:
    host = (urlsplit(url).hostname or "").lower()
    if host.endswith(("tiktok.com", "tiktokv.com")):
        return "TikTok"
    if host.endswith(("instagram.com", "instagr.am")):
        return "Instagram"
    if host.endswith(("youtube.com", "youtu.be")):
        return "YouTube"
    if host.endswith(("facebook.com", "fb.watch", "fb.com")):
        return "Facebook"
    if host.endswith("google.com") and host.startswith("drive."):
        return "Google Drive"
    return "Web video"


def ext_for(url: str) -> str:
    path = urlsplit(url).path
    match = re.search(r"\.(mp4|m4v|mov|webm|m3u8)$", path, re.I)
    return match.group(1).lower() if match else "mp4"


def parse_html_media(html: str, base_url: str) -> tuple[str, list[str]]:
    soup = BeautifulSoup(html, "html.parser")
    title = (soup.title.get_text(" ", strip=True) if soup.title else "") or "Website video"
    addresses: list[str] = []

    for node in soup.select("video, video source, source, meta[property], meta[name]"):
        value = None
        if node.name in ("video", "source"):
            value = node.get("src") or node.get("data-src") or node.get("data-video")
        elif node.name == "meta":
            field_name = (node.get("property") or node.get("name") or "").lower()
            if field_name in {"og:video", "og:video:url", "og:video:secure_url", "twitter:player:stream"}:
                value = node.get("content")
        if value:
            addresses.append(str(value))

    for script in soup.select('script[type="application/ld+json"]'):
        try:
            records = json.loads(script.get_text() or "null")
            objects = records if isinstance(records, list) else [records]
            for obj in objects:
                if isinstance(obj, dict) and obj.get("contentUrl"):
                    addresses.append(str(obj["contentUrl"]))
        except (ValueError, TypeError):
            pass

    for match in MEDIA_LINKS.findall(html):
        addresses.append(match)

    urls: list[str] = []
    for raw in addresses:
        value = unescape(raw).replace("\\/", "/").replace("\\u0026", "&").strip()
        if not value or value.startswith(("blob:", "data:")):
            continue
        try:
            resolved = urljoin(base_url, value)
            if VIDEO_SUFFIX.search(resolved) and resolved not in urls:
                # Validate DNS asynchronously when fetching, not while parsing.
                ensure_public_url(resolved, resolve_dns=False)
                urls.append(resolved)
        except (ValueError, LinkError):
            pass
        if len(urls) >= MAX_MEDIA_CANDIDATES:
            break
    return title.strip()[:160], urls


async def _probe(url: str, *, referrer: str = "") -> tuple[bool, int | None]:
    headers = {"Range": "bytes=0-2047"}
    if referrer:
        headers["Referer"] = referrer
    try:
        response = await safe_request(url, headers=headers, read_limit=4096, strict_limit=False)
        if response.status_code not in (200, 206):
            return False, None
        content = response.content[:2048]
        mime = response.headers.get("content-type", "").lower()
        if any(value in mime for value in ("text/html", "application/json", "application/xml")):
            return False, None
        if HLS_VIDEO.search(url):
            valid = content.lstrip().startswith(b"#EXTM3U")
        else:
            valid = (len(content) >= 8 and content[4:8] in {b"ftyp", b"moov", b"mdat"}) or content.startswith(b"\x1aE\xdf\xa3")
        length = response.headers.get("content-range", "")
        total_match = re.search(r"/(\d+)$", length)
        total = int(total_match.group(1)) if total_match else None
        if not total and response.headers.get("content-length") and response.status_code == 200:
            total = int(response.headers["content-length"])
        return valid, total
    except (LinkError, httpx.HTTPError, OSError):
        return False, None


async def _direct(url: str) -> Result | None:
    # Try a small ranged response. HEAD is often blocked even when GET works.
    if not (DIRECT_VIDEO.search(url) or HLS_VIDEO.search(url)):
        return None
    valid, size = await _probe(url)
    if not valid:
        return None
    kind = "hls" if HLS_VIDEO.search(url) else "direct"
    ext = ext_for(url)
    return Result(url, urlsplit(url).path.rsplit("/", 1)[-1] or "Video", "Web video", [
        Choice("direct", f"Original {ext.upper()}", kind, url, ext, size),
    ], method="Direct media")


def _extract_yt_sync(url: str) -> Result | None:
    try:
        import yt_dlp
    except ImportError:
        return None
    options = {
        "quiet": True, "no_warnings": True, "skip_download": True,
        "noplaylist": True, "extract_flat": False,
        "socket_timeout": 12, "retries": 1, "extractor_retries": 1,
        "ignoreerrors": False,
    }
    try:
        with yt_dlp.YoutubeDL(options) as ydl:
            info = ydl.extract_info(url, download=False)
    except Exception:
        return None
    if not isinstance(info, dict) or info.get("is_live"):
        return None
    platform = platform_name(url)
    title = (info.get("title") or f"{platform} video")[:160]
    choices: list[Choice] = []
    candidates = info.get("formats") or [info]
    for fmt in candidates:
        if not isinstance(fmt, dict):
            continue
        if fmt.get("has_drm") or fmt.get("vcodec") in (None, "none"):
            continue
        if fmt.get("acodec") == "none":
            continue  # We must not silently hand out videos missing their audio.
        ext = str(fmt.get("ext") or "mp4").lower()
        if ext not in ("mp4", "webm", "mov", "m4v"):
            continue
        fid = str(fmt.get("format_id") or "best")
        if len(fid) > 80 or not re.fullmatch(r"[A-Za-z0-9_.+\-]+", fid):
            continue
        protocol = str(fmt.get("protocol") or "http")
        height = fmt.get("height")
        size = fmt.get("filesize") or fmt.get("filesize_approx")
        label = f"{height}p · {ext.upper()} · with audio" if height else f"{ext.upper()} · with audio"
        if protocol.startswith("m3u8"):
            label += " · HLS"
        choices.append(Choice(
            id=f"yt{len(choices)}", label=label,
            source="yt-dlp", url=url, ext=ext,
            size=int(size) if isinstance(size, (float, int)) and size > 0 else None,
            height=int(height) if isinstance(height, (float, int)) else None,
            ytdlp_id=fid,
        ))
        if len(choices) >= 20:
            break
    if not choices:
        # Some sites offer separate audio+video; yt-dlp with ffmpeg can merge them.
        if any(isinstance(f, dict) and f.get("vcodec") not in (None, "none") for f in candidates):
            choices = [Choice("ytbest", "Best compatible video + audio (FFmpeg)", "yt-dlp", url, ytdlp_id="bv*+ba/b")]
    if not choices:
        return None
    choices.sort(key=lambda q: (q.height or 0), reverse=True)
    return Result(url, title, platform, choices[:10], thumbnail=str(info.get("thumbnail") or ""),
                  duration=info.get("duration"), method="yt-dlp")


async def _scan_html(url: str) -> Result | None:
    response = await safe_request(url, headers={"Accept": "text/html,application/xhtml+xml"})
    if response.status_code != 200:
        return None
    if "html" not in response.headers.get("content-type", "").lower():
        return None
    html = response.text[:MAX_HTML]
    title, candidates = parse_html_media(html, url)
    if not candidates:
        return None
    sem = asyncio.Semaphore(4)

    async def candidate_check(raw: str):
        async with sem:
            return await _probe(raw, referrer=url)

    checks = await asyncio.gather(*(candidate_check(link) for link in candidates), return_exceptions=True)
    choices = []
    for link, check in zip(candidates, checks):
        if isinstance(check, Exception):
            continue
        valid, size = check
        if valid:
            ext = ext_for(link)
            source = "hls" if ext == "m3u8" else "direct"
            choices.append(Choice(
                id=f"html{len(choices)}", label=f"Embedded {len(choices) + 1} · {ext.upper()}" + (" stream" if ext == "m3u8" else ""),
                source=source, url=link, ext=ext, size=size,
                headers={"Referer": url},
            ))
        if len(choices) >= 8:
            break
    if not choices:
        return None
    return Result(url, title, "Web video", choices, method="HTML video scanner")


async def _scan_browser(url: str) -> Result | None:
    """Optional best-effort *public* media detection; no DRM/cookies/login bypass."""
    try:
        from playwright.async_api import async_playwright
    except ImportError:
        return None
    found: list[str] = []
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True, args=["--no-sandbox"])
        try:
            ctx = await browser.new_context(ignore_https_errors=False, service_workers="block")
            # Route all requests and reject non-public network destinations.
            async def guard(route):
                try:
                    ensure_public_url(route.request.url)
                    await route.continue_()
                except Exception:
                    await route.abort()
            await ctx.route("**/*", guard)
            page = await ctx.new_page()
            def observe(response):
                url2 = response.url
                mime = response.headers.get("content-type", "")
                if response.status in (200, 206) and (VIDEO_SUFFIX.search(url2) or mime.startswith("video/")):
                    if url2 not in found and len(found) < MAX_MEDIA_CANDIDATES:
                        found.append(url2)
            page.on("response", observe)
            await page.goto(url, wait_until="domcontentloaded", timeout=15000)
            await page.wait_for_timeout(1800)
            title = await page.title() or "Website video"
            html = await page.content()
            _, static_sources = parse_html_media(html[:MAX_HTML], url)
            found.extend(x for x in static_sources if x not in found)
        finally:
            await browser.close()
    choices: list[Choice] = []
    for media_url in found[:10]:
        valid, size = await _probe(media_url, referrer=url)
        if valid:
            ext = ext_for(media_url)
            choices.append(Choice(
                id=f"browser{len(choices)}", label=f"Browser detected · {ext.upper()}",
                source="hls" if ext == "m3u8" else "direct", url=media_url, ext=ext,
                size=size, headers={"Referer": url},
            ))
        if len(choices) >= 5:
            break
    if not choices:
        return None
    return Result(url, title[:160], "Web video", choices, method="Browser network observer")


async def inspect(url: str, *, browser: bool = False) -> Result:
    url = ensure_public_url(url)
    direct = await _direct(url)
    if direct:
        return direct
    # yt-dlp supports TikTok, YouTube, Facebook, Instagram, Drive and generic pages.
    # Run its sync networking in a thread to avoid blocking server.
    yt = await asyncio.to_thread(_extract_yt_sync, url)
    if yt:
        return yt
    try:
        html = await _scan_html(url)
    except (httpx.HTTPError, LinkError):
        html = None
    if html:
        return html
    if browser:
        try:
            result = await _scan_browser(url)
            if result:
                return result
        except Exception:
            pass
    raise LinkError(
        "No accessible video file was found at that address. The player may load a private "
        "stream, require a browser session, or use DRM. Copy the address of the actual video page."
    )
