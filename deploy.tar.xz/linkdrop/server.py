"""LinkDrop Independent. Run: uvicorn linkdrop.server:app --host 0.0.0.0 --port 8765"""
from __future__ import annotations

import asyncio
from dataclasses import dataclass, field
import os
from pathlib import Path
import secrets
import shutil
import tempfile
import time
import uuid

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from .extractor import Result, inspect
from .downloader import download_choice
from .security import LinkError

ROOT = Path(__file__).resolve().parent.parent
STATIC = ROOT / "static"
FILES = Path(tempfile.gettempdir()) / "linkdrop-independent"
FILES.mkdir(exist_ok=True)
RESULT_TTL = 40 * 60
FILE_TTL = 40 * 60
MAX_CONCURRENT = 2

app = FastAPI(title="LinkDrop Independent", docs_url=None, redoc_url=None)
app.mount("/static", StaticFiles(directory=STATIC), name="static")

ACCESS_KEY = os.environ.get("LINKDROP_ACCESS_KEY", "").strip()


@app.middleware("http")
async def guard_paid_hosting(request: Request, call_next):
    """Optional access key for a private hosted instance. Local use needs none."""
    path = request.url.path
    restricted = path.startswith("/api/") and path not in ("/api/health",)
    # File URLs use short-lived, unguessable 128-bit job tokens instead of headers,
    # because Safari's native file and video elements cannot attach custom headers.
    restricted = restricted and not path.startswith(("/api/files/", "/api/preview/"))
    if ACCESS_KEY and restricted:
        entered = request.headers.get("X-LinkDrop-Key", "")
        if not secrets.compare_digest(entered, ACCESS_KEY):
            return JSONResponse({"ok": False, "error": "Your private LinkDrop access key is required."}, status_code=401)
    return await call_next(request)


@dataclass
class ScanRecord:
    result: Result
    created: float = field(default_factory=time.monotonic)


@dataclass
class DownloadRecord:
    status: str = "working"
    progress: int = 0
    message: str = "Starting download"
    filename: str = ""
    size: int = 0
    path: Path | None = None
    error: str = ""
    created: float = field(default_factory=time.monotonic)


scans: dict[str, ScanRecord] = {}
downloads: dict[str, DownloadRecord] = {}
capacity = asyncio.Semaphore(MAX_CONCURRENT)


class InspectRequest(BaseModel):
    url: str = Field(min_length=8, max_length=4096)
    browser: bool = False


class PrepareRequest(BaseModel):
    scan_id: str
    quality: str


def error_message(exc: Exception) -> str:
    text = str(exc)
    # This is displayed to users, so don't reveal filesystem paths, cookies or full signed URLs.
    if isinstance(exc, LinkError):
        return text[:260]
    return "The source could not be downloaded. Try another quality or a public video link."


def housekeeping():
    now = time.monotonic()
    for key, value in list(scans.items()):
        if now - value.created > RESULT_TTL:
            scans.pop(key, None)
    for key, value in list(downloads.items()):
        if now - value.created > FILE_TTL:
            if value.path and value.path.exists():
                shutil.rmtree(value.path.parent, ignore_errors=True)
            downloads.pop(key, None)


@app.get("/")
async def homepage():
    return FileResponse(STATIC / "index.html")


@app.get("/manifest.webmanifest")
async def manifest():
    return FileResponse(STATIC / "manifest.webmanifest", media_type="application/manifest+json")


@app.get("/api/health")
async def health():
    try:
        import yt_dlp
        has_yt = True
    except ImportError:
        has_yt = False
    return {
        "ok": True,
        "engine": "LinkDrop Independent 1.0",
        "ytdlp": has_yt,
        "ffmpeg": bool(shutil.which("ffmpeg")),
        "browser": bool(__import__("importlib").util.find_spec("playwright")),
        "access_key_required": bool(ACCESS_KEY),
        "cost": "No paid API",
        "max_mb": 50,
    }


@app.post("/api/inspect")
async def inspect_route(payload: InspectRequest):
    housekeeping()
    try:
        result = await asyncio.wait_for(inspect(payload.url, browser=payload.browser), timeout=60)
        token = uuid.uuid4().hex
        scans[token] = ScanRecord(result)
        return {"ok": True, "scan_id": token, "video": result.public_dict()}
    except (LinkError, ValueError) as exc:
        return JSONResponse({"ok": False, "error": str(exc)[:280]}, status_code=422)
    except asyncio.TimeoutError:
        return JSONResponse({"ok": False, "error": "The website took too long to respond. Try the direct video link."}, status_code=504)
    except Exception:
        return JSONResponse({"ok": False, "error": "The video page couldn't be inspected. It may block automated access."}, status_code=502)


async def _prepare_job(job_id: str, scanned: ScanRecord, choice):
    job = downloads[job_id]
    folder = FILES / job_id
    def report(percent: int, msg: str):
        job.progress = max(0, min(100, int(percent)))
        job.message = msg
    try:
        async with capacity:
            job.message = "Finding downloadable video"
            file = await asyncio.wait_for(
                download_choice(choice, scanned.result.title, folder, report),
                timeout=150,
            )
            job.path = file
            job.filename = file.name
            job.size = file.stat().st_size
            job.progress = 100
            job.status = "ready"
            job.message = "Your video is ready"
    except Exception as exc:
        job.status = "failed"
        job.error = error_message(exc)
        job.message = "Could not download this video"
        shutil.rmtree(folder, ignore_errors=True)


@app.post("/api/prepare")
async def prepare(payload: PrepareRequest):
    housekeeping()
    item = scans.get(payload.scan_id)
    if not item:
        raise HTTPException(404, "This video lookup expired. Find the video again.")
    choice = next((q for q in item.result.choices if q.id == payload.quality), None)
    if choice is None:
        raise HTTPException(400, "Choose a listed video quality first.")
    task_id = uuid.uuid4().hex
    downloads[task_id] = DownloadRecord()
    asyncio.create_task(_prepare_job(task_id, item, choice))
    return {"ok": True, "job_id": task_id}


@app.get("/api/jobs/{job_id}")
async def job_status(job_id: str):
    housekeeping()
    job = downloads.get(job_id)
    if not job:
        raise HTTPException(404, "This download expired. Please prepare it again.")
    return {
        "status": job.status,
        "progress": job.progress,
        "message": job.message,
        "error": job.error,
        "filename": job.filename if job.status == "ready" else "",
        "bytes": job.size if job.status == "ready" else 0,
        "download_url": f"/api/files/{job_id}" if job.status == "ready" else None,
        "preview_url": f"/api/preview/{job_id}" if job.status == "ready" else None,
    }


def _file(job_id: str) -> DownloadRecord:
    housekeeping()
    job = downloads.get(job_id)
    if not job or job.status != "ready" or not job.path or not job.path.is_file():
        raise HTTPException(404, "The video has expired. Prepare it again.")
    return job


@app.get("/api/files/{job_id}")
async def download_file(job_id: str):
    job = _file(job_id)
    return FileResponse(job.path, filename=job.filename, media_type="video/mp4" if job.path.suffix == ".mp4" else "application/octet-stream")


@app.get("/api/preview/{job_id}")
async def preview(job_id: str):
    job = _file(job_id)
    return FileResponse(job.path, media_type="video/mp4" if job.path.suffix == ".mp4" else "video/webm")
