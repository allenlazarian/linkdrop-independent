"""Bounded media downloads with free software, no paid video API."""
from __future__ import annotations

import asyncio
from pathlib import Path
import re
import shutil

from .extractor import Choice
from .security import LinkError, ensure_public_url, safe_request

MAX_BYTES = 50 * 1024 * 1024


def filename_safe(value: str) -> str:
    value = re.sub(r"[^a-zA-Z0-9 ._()-]", "", value).strip(" ._")
    return (value[:85].strip() or "video")


async def download_choice(choice: Choice, title: str, directory: Path, report) -> Path:
    ensure_public_url(choice.url)
    directory.mkdir(parents=True, exist_ok=True)
    if choice.source == "direct":
        report(10, "Fetching original video")
        result = await safe_request(
            choice.url, headers=choice.headers, timeout=35.0,
            read_limit=MAX_BYTES,
        )
        if result.status_code not in (200, 206):
            raise LinkError(f"Video host returned HTTP {result.status_code}. The file may have expired or be restricted.")
        data = result.content
        if len(data) < 8 or (data[4:8] not in (b"ftyp", b"moov", b"mdat") and not data.startswith(b"\x1aE\xdf\xa3")):
            raise LinkError("The video host returned a webpage instead of a playable video file.")
        if len(data) > MAX_BYTES:
            raise LinkError("The video is over the 50 MB limit.")
        output = directory / f"{filename_safe(title)}.{choice.ext if choice.ext != 'm4v' else 'mp4'}"
        output.write_bytes(data)
        report(100, "Download ready")
        return output
    return await asyncio.to_thread(_yt_download_sync, choice, title, directory, report)


def _yt_download_sync(choice: Choice, title: str, directory: Path, report) -> Path:
    try:
        import yt_dlp
    except ImportError:
        raise LinkError("yt-dlp is not installed yet. See the setup instructions.")
    ffmpeg = shutil.which("ffmpeg")
    if choice.source == "hls" and not ffmpeg:
        raise LinkError("FFmpeg is required to assemble HLS streams. Install FFmpeg and retry.")
    output_base = directory / "video"
    def on_progress(event):
        if event.get("status") == "downloading":
            total = event.get("total_bytes") or event.get("total_bytes_estimate") or 0
            downloaded = event.get("downloaded_bytes") or 0
            if downloaded > MAX_BYTES:
                raise LinkError("The downloaded file is over the 50 MB limit.")
            pct = min(92, round(downloaded * 90 / total)) if total else 20
            report(pct, "Downloading video")
        elif event.get("status") == "finished":
            report(94, "Finalising MP4")

    fmt = choice.ytdlp_id or "best"
    options = {
        "quiet": True,
        "no_warnings": True,
        "noplaylist": True,
        "ignoreerrors": False,
        "outtmpl": str(output_base) + ".%(ext)s",
        "format": fmt,
        "max_filesize": MAX_BYTES,
        "noprogress": True,
        "progress_hooks": [on_progress],
        "retries": 1,
        "fragment_retries": 1,
        "socket_timeout": 20,
        "merge_output_format": "mp4",
    }
    if choice.headers:
        options["http_headers"] = choice.headers
    report(12, "Extracting playable media")
    try:
        with yt_dlp.YoutubeDL(options) as dl:
            dl.download([choice.url])
    except Exception as exc:
        raise LinkError(f"The video service could not retrieve this media: {str(exc)[:220]}") from exc
    files = [p for p in directory.glob("video.*") if p.is_file() and not p.name.endswith((".part", ".ytdl"))]
    if not files:
        raise LinkError("The video extractor did not produce a file.")
    output = max(files, key=lambda p: p.stat().st_size)
    if output.stat().st_size <= 0 or output.stat().st_size > MAX_BYTES:
        raise LinkError("The prepared file is empty or exceeds the 50 MB limit.")
    renamed = directory / f"{filename_safe(title)}{output.suffix}"
    output.rename(renamed)
    report(100, "Download ready")
    return renamed
