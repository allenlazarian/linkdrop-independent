"""LinkDrop Independent open-source-inspired standalone downloader."""
