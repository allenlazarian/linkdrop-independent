"""Conservative URL filtering for an untrusted paste-a-link endpoint."""
from __future__ import annotations

import ipaddress
import re
import socket
from urllib.parse import urljoin, urlsplit, urlunsplit

import httpx

ALLOWED_SCHEMES = {"http", "https"}
MAX_REDIRECTS = 5
URL_LIMIT = 4096


class LinkError(ValueError):
    pass


def clean_url(text: str) -> str:
    if not isinstance(text, str):
        raise LinkError("Paste a video link first.")
    text = text.strip()
    match = re.search(r"https?://[^\s<>\"']+", text, re.I)
    if match:
        text = match.group(0)
    if len(text) < 8 or len(text) > URL_LIMIT:
        raise LinkError("Paste a complete video URL.")
    parts = urlsplit(text)
    if parts.scheme not in ALLOWED_SCHEMES or not parts.hostname or parts.username or parts.password:
        raise LinkError("Only public http/https video links are supported.")
    if parts.port and parts.port not in (80, 443):
        raise LinkError("Video links must use the normal web ports (80 or 443).")
    return urlunsplit((parts.scheme, parts.netloc, parts.path or "/", parts.query, ""))


def _addresses_are_public(host: str) -> bool:
    # Reject local hostnames, DNS-resolved private IPs and link-local metadata services.
    if not host or host.lower().rstrip(".") in {"localhost", "localhost.localdomain"}:
        return False
    if host.lower().endswith((".local", ".internal", ".localhost", ".test", ".invalid")):
        return False
    try:
        return ipaddress.ip_address(host).is_global
    except ValueError:
        pass
    try:
        resolved = socket.getaddrinfo(host, None, proto=socket.IPPROTO_TCP)
        return bool(resolved) and all(ipaddress.ip_address(item[4][0]).is_global for item in resolved)
    except (socket.gaierror, ValueError):
        return False


def ensure_public_url(raw: str, *, resolve_dns: bool = True) -> str:
    value = clean_url(raw)
    if resolve_dns and not _addresses_are_public(urlsplit(value).hostname or ""):
        raise LinkError("This address is not a publicly accessible website.")
    return value


async def safe_request(
    url: str,
    *,
    method: str = "GET",
    headers: dict[str, str] | None = None,
    timeout: float = 15.0,
    read_limit: int = 2 * 1024 * 1024,
    strict_limit: bool = True,
) -> httpx.Response:
    """Safely fetch a bounded number of bytes; validate all redirects and their DNS."""
    url = ensure_public_url(url)
    h = {
        "User-Agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 Version/17.0 Mobile/15E148 Safari/604.1",
        "Accept": "*/*",
        **(headers or {}),
    }
    async with httpx.AsyncClient(timeout=timeout, follow_redirects=False, trust_env=False) as client:
        for _ in range(MAX_REDIRECTS + 1):
            async with client.stream(method, url, headers=h) as resp:
                if resp.status_code in {301, 302, 303, 307, 308}:
                    redirect = resp.headers.get("location")
                    if not redirect:
                        raise LinkError("The video site returned an invalid redirect.")
                    url = ensure_public_url(urljoin(url, redirect))
                    h.pop("Authorization", None)
                    h.pop("Cookie", None)
                    continue
                if strict_limit and int(resp.headers.get("content-length") or "0") > read_limit:
                    raise LinkError("This video exceeds the configured 50 MB limit.")
                data = bytearray()
                async for chunk in resp.aiter_bytes():
                    if len(data) + len(chunk) > read_limit:
                        if strict_limit:
                            raise LinkError("This video exceeds the configured 50 MB limit.")
                        data.extend(chunk[:max(0, read_limit - len(data))])
                        break
                    data.extend(chunk)
                    if len(data) >= read_limit and not strict_limit:
                        break
                return httpx.Response(
                    status_code=resp.status_code,
                    headers=dict(resp.headers), content=bytes(data),
                    request=resp.request,
                )
    raise LinkError("The website redirected too many times.")
