'use strict';
const $ = id => document.getElementById(id);
const SAMPLE = 'https://www.w3schools.com/html/mov_bbb.mp4';
const HISTORY = 'linkdrop-independent-recent-v1';
let currentScan = null;
let currentVideo = null;
let lastAction = 'inspect';
let activePoll = false;
let currentFile = null;

function reveal(id, yes) { $(id).hidden = !yes; }
function message(text) { $('status-text').textContent = text; reveal('status-notice', !!text); }
function error(text) { $('error-message').textContent = text; reveal('error-card', true); message(''); }
function clearError() { reveal('error-card', false); message(''); }
function busy(state, action = 'find') {
  $('find-btn').disabled = state;
  $('download-btn').disabled = state;
  $('paste-btn').disabled = state;
  if (state && action === 'find') $('find-btn').innerHTML = '<span>Finding your video…</span><span class="arrow">◌</span>';
  else $('find-btn').innerHTML = '<span>Find my video</span><span class="arrow">→</span>';
  $('download-btn').textContent = state && action === 'download' ? 'Preparing video…' : '↓  Prepare download';
}
function platform(url) {
  try {
    const host = new URL(url).hostname.toLowerCase();
    if (host.endsWith('tiktok.com')) return 'TikTok';
    if (host.endsWith('youtube.com') || host === 'youtu.be') return 'YouTube';
    if (host.endsWith('instagram.com')) return 'Instagram';
    if (host.endsWith('facebook.com') || host === 'fb.watch') return 'Facebook';
    if (host === 'drive.google.com') return 'Google Drive';
    return 'Web video';
  } catch { return 'https://'; }
}
function sourceChange() {
  let url = $('video-url').value.trim();
  $('source-detection').textContent = url ? '✓  ' + platform(url) : 'https://';
  reveal('clear-btn', !!url);
  $('shortcut-btn').href = url
    ? 'shortcuts://run-shortcut?name=SW-DLT&input=text&text=' + encodeURIComponent(url)
    : '#';
}
function resetResult() {
  currentScan = null;
  currentVideo = null;
  currentFile = null;
  reveal('video-result', false);
  reveal('progress-area', false);
  reveal('ready-area', false);
  reveal('quality-area', true);
  clearError();
}
function authHeaders(extra = {}) {
  const key = sessionStorage.getItem('linkdrop-access-key') || '';
  return {...extra, ...(key ? {'X-LinkDrop-Key': key} : {})};
}
async function sendJSON(route, data) {
  let response;
  try {
    const options = () => ({method:'POST', headers:authHeaders({'Content-Type':'application/json'}), body:JSON.stringify(data)});
    response = await fetch(route, options());
    if (response.status === 401) {
      const key = prompt('Enter the access key you configured for your private LinkDrop server:');
      if (!key) throw new Error('The server needs its access key.');
      sessionStorage.setItem('linkdrop-access-key', key);
      response = await fetch(route, options());
    }
  } catch (ex) {
    if (ex instanceof Error && ex.message.includes('access key')) throw ex;
    throw new Error('Cannot contact the download server. Make sure LinkDrop is running.');
  }
  const json = await response.json().catch(() => ({}));
  if (!response.ok || json.ok === false) throw new Error(json.error || json.detail || 'The request failed.');
  return json;
}
const sizeText = n => n ? (n / 1024 / 1024).toFixed(1) + ' MB' : 'Size unknown';
function saveRecent(video) {
  try {
    const existing = JSON.parse(localStorage.getItem(HISTORY) || '[]');
    const recent = [{url: video.url, title:video.title, platform:video.platform}, ...existing.filter(x => x.url !== video.url)].slice(0,6);
    localStorage.setItem(HISTORY, JSON.stringify(recent));
    displayRecent();
  } catch {}
}
function displayRecent() {
  const list = $('recent-list');
  list.replaceChildren();
  let recent = [];
  try { recent = JSON.parse(localStorage.getItem(HISTORY) || '[]'); } catch {}
  if (!recent.length) { const p=document.createElement('p'); p.className='empty-history'; p.textContent='Your recently used video links stay on this device.'; list.append(p); return; }
  for (const item of recent.slice(0,5)) {
    const btn = document.createElement('button'); btn.className='recent-entry';
    const title = document.createElement('span'); title.textContent=item.title;
    const more = document.createElement('small'); more.textContent='↗';
    btn.append(title, more);
    btn.addEventListener('click', ()=>{$('video-url').value=item.url; sourceChange(); inspect(); document.querySelector('.panel').scrollIntoView({behavior:'smooth'});});
    list.append(btn);
  }
}
async function inspect() {
  const url = $('video-url').value.trim();
  resetResult();
  if (!url) { error('Paste a public video or webpage address first.'); return; }
  if (!/^https?:\/\//i.test(url)) { error('Copy the entire URL including https://.'); return; }
  busy(true, 'find'); lastAction = 'inspect';
  try {
    const data = await sendJSON('/api/inspect', {url, browser:$('browser-scan').checked});
    currentScan = data.scan_id; currentVideo = data.video;
    $('result-title').textContent = data.video.title;
    $('result-platform').textContent = data.video.platform + (data.video.duration ? ' · ' + Math.floor(data.video.duration/60) + ':' + String(Math.floor(data.video.duration%60)).padStart(2,'0') : '');
    $('found-method').textContent = 'Video found · ' + (data.video.method || 'Public source');
    const thumb = $('thumbnail'); thumb.replaceChildren();
    if (data.video.thumbnail && /^https:\/\//i.test(data.video.thumbnail)) {
      const img = document.createElement('img'); img.src=data.video.thumbnail; img.alt='Video thumbnail'; img.referrerPolicy='no-referrer';
      img.onerror=()=>{img.remove();thumb.textContent='▶';}; thumb.append(img);
    } else thumb.textContent='▣';
    const select = $('quality'); select.replaceChildren();
    for (const q of data.video.qualities) {
      const option = document.createElement('option'); option.value=q.id;
      option.textContent=q.label+(q.bytes?' · '+sizeText(q.bytes):''); select.append(option);
    }
    reveal('video-result',true); reveal('quality-area',true); saveRecent(data.video);
  } catch (e) { error(e.message || 'Unable to inspect this link.'); }
  finally { busy(false); }
}
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
async function prepare() {
  if (!currentScan || activePoll) return;
  clearError(); lastAction='download'; busy(true,'download');activePoll=true;
  reveal('quality-area',false);reveal('progress-area',true);reveal('ready-area',false);
  $('progress-bar').style.width='0%';$('progress-percent').textContent='0%';
  try {
    const prepared=await sendJSON('/api/prepare',{scan_id:currentScan,quality:$('quality').value});
    let status;
    for (let tries=0;tries<180;tries++) {
      const response=await fetch('/api/jobs/'+encodeURIComponent(prepared.job_id),{cache:'no-store',headers:authHeaders()});
      status=await response.json();
      if (!response.ok) throw new Error(status.detail || 'The download expired.');
      $('progress-label').textContent=status.message || 'Preparing video';
      $('progress-percent').textContent=(status.progress||0)+'%';
      $('progress-bar').style.width=(status.progress||0)+'%';
      if (status.status==='ready' || status.status==='failed') break;
      await sleep(850);
    }
    if (!status || status.status!=='ready') throw new Error(status?.error || 'The video could not be prepared. Try a different link.');
    currentFile = status;
    $('file-info').textContent = status.filename+' · '+sizeText(status.bytes);
    $('preview').src=status.preview_url;
    $('files-link').href=status.download_url;
    $('files-link').setAttribute('download',status.filename);
    reveal('progress-area',false);reveal('ready-area',true);
  } catch(e) {reveal('quality-area',true);reveal('progress-area',false);error(e.message || 'Download failed.');}
  finally { activePoll=false;busy(false); }
}
async function share() {
  if (!currentFile) return;
  try {
    message('Preparing the video for your iPhone share menu…');
    const response = await fetch(currentFile.download_url);
    if (!response.ok) throw new Error('The prepared video expired.');
    const blob = await response.blob();
    const file = new File([blob], currentFile.filename, {type:blob.type || 'video/mp4'});
    if (navigator.share && navigator.canShare && navigator.canShare({files:[file]})) {
      message(''); await navigator.share({files:[file],title:file.name});
    } else {
      message('If the share menu is unavailable, use Download to Files below. On iPhone, open LinkDrop in Safari.');
      $('files-link').click();
    }
  } catch(e) { if (e.name !== 'AbortError') error(e.message || 'Use Download to Files instead.'); }
}
$('find-form').addEventListener('submit', e => {e.preventDefault();inspect();});
$('video-url').addEventListener('input',()=>{sourceChange();resetResult();});
$('paste-btn').addEventListener('click', async()=>{try {const text=await navigator.clipboard.readText();$('video-url').value=text;sourceChange();resetResult();}catch {message('Tap and hold in the link box, then choose Paste.');$('video-url').focus();}});
$('clear-btn').addEventListener('click',()=>{$('video-url').value='';sourceChange();resetResult();$('video-url').focus();});
$('sample-btn').addEventListener('click',()=>{$('video-url').value=SAMPLE;sourceChange();inspect();});
$('download-btn').addEventListener('click',prepare);
$('retry-btn').addEventListener('click',()=>lastAction==='download'&&currentScan?prepare():inspect());
$('share-btn').addEventListener('click',share);
$('another-btn').addEventListener('click',()=>{$('video-url').value='';sourceChange();resetResult();window.scrollTo({top:0,behavior:'smooth'});});
$('clear-history').addEventListener('click',()=>{localStorage.removeItem(HISTORY);displayRecent();});
$('help-toggle').addEventListener('click',()=>$('help-dialog').showModal());
$('close-help').addEventListener('click',()=>$('help-dialog').close());
$('got-it').addEventListener('click',()=>$('help-dialog').close());
$('shortcut-btn').addEventListener('click',event=>{if(!$('video-url').value.trim()){event.preventDefault();error('Paste a video link to use the iPhone shortcut.');}});
async function health() { try {const res=await fetch('/api/health');const data=await res.json();$('engine-state').textContent=data.ytdlp?'Downloader online · FFmpeg '+(data.ffmpeg?'ready':'not found'):'Basic webpage scanner ready · install yt-dlp for social video downloads';}catch {$('engine-state').textContent='Server unavailable';}}
sourceChange();displayRecent();health();
